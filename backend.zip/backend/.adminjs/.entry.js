AdminJS.UserComponents = {}
import RoleUser from '../src/components/role-user'
AdminJS.UserComponents.RoleUser = RoleUser
import UserRole from '../src/components/user-role'
AdminJS.UserComponents.UserRole = UserRole